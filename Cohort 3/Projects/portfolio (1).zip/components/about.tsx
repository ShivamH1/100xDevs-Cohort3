import { Card, CardContent } from "@/components/ui/card"
import { Mail, Phone, MapPin } from "lucide-react"

export function About() {
  return (
    <section id="about" className="py-12 px-6 lg:px-8 bg-zinc-900">
      <div className="max-w-7xl mx-auto">
        <h2 className="text-3xl font-bold mb-12 text-center">About Me</h2>
        <div className="grid lg:grid-cols-2 gap-12">
          <div>
            <p className="text-zinc-400">
              As a Full Stack Developer, I have a solid background in designing and developing web applications. My
              expertise includes JavaScript, Python, ReactJS, and various frameworks.
            </p>
            <p className="mt-4 text-zinc-400">
              I am passionate about open-source projects and improving user experience through efficient code. I am
              committed to continuous learning, enhancing code performance, and leading full-stack application
              development.
            </p>
            <div className="mt-6 space-y-4">
              <div className="flex items-center gap-3 text-zinc-400">
                <Mail className="h-5 w-5" />
                <span>shivamhonrao.sae.comp@gmail.com</span>
              </div>
              <div className="flex items-center gap-3 text-zinc-400">
                <Phone className="h-5 w-5" />
                <span>7498481659</span>
              </div>
              <div className="flex items-center gap-3 text-zinc-400">
                <MapPin className="h-5 w-5" />
                <span>Pune, India</span>
              </div>
            </div>
          </div>
          <div>
            <Card className="bg-zinc-800 border-zinc-700">
              <CardContent className="p-6">
                <h3 className="text-xl font-semibold mb-4">Quick Facts</h3>
                <ul className="space-y-2 text-zinc-400">
                  <li>• Full Stack Developer</li>
                  <li>• Open Source Contributor</li>
                  <li>• UI/UX Enthusiast</li>
                  <li>• Performance Optimization Expert</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  )
}

