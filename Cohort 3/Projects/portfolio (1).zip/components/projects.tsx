import { Card, CardContent } from "@/components/ui/card"
import { ExternalLink, Github } from "lucide-react"

const projects = [
  {
    title: "Shiptivitas",
    description: "Open Source Contribution at Forage",
    details: [
      "Contributed to optimizing key modules, achieving 15% reduction in code execution time",
      "Implemented Kanban board feature for shipping request tracking",
    ],
    github: "#",
  },
  {
    title: "JPMC Perspective",
    description: "Open Source Contribution at Forage",
    details: [
      "Created dynamic graphs using JPMorgan Chase's Perspective library",
      "Enhanced trading data visualization with real-time updates",
    ],
    github: "#",
  },
  {
    title: "Transaction Application",
    description: "Full Stack Development",
    details: [
      "Built with React, Express, and MongoDB",
      "Implemented secure user authentication using Zod",
      "Features include balance display and user transfers",
    ],
    github: "#",
  },
]

export function Projects() {
  return (
    <section id="projects" className="py-12 px-6 lg:px-8 bg-zinc-900">
      <div className="max-w-7xl mx-auto">
        <h2 className="text-3xl font-bold mb-12 text-center">Projects</h2>
        <div className="grid md:grid-cols-2 gap-6">
          {projects.map((project, index) => (
            <Card key={index} className="bg-zinc-800/50 border-zinc-700">
              <CardContent className="p-6">
                <div className="flex justify-between items-start">
                  <h3 className="text-xl font-semibold">{project.title}</h3>
                  <div className="flex gap-2">
                    <a href={project.github} className="hover:text-blue-500">
                      <Github className="h-5 w-5" />
                    </a>
                    <a href="#" className="hover:text-blue-500">
                      <ExternalLink className="h-5 w-5" />
                    </a>
                  </div>
                </div>
                <p className="text-zinc-400 mt-2">{project.description}</p>
                <ul className="mt-4 space-y-2">
                  {project.details.map((detail, idx) => (
                    <li key={idx} className="text-zinc-400">
                      • {detail}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}

